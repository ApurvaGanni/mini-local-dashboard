
# 🚀 Mini Local Business Dashboard

A full-stack assignment project simulating a local business dashboard using React + Tailwind (Frontend) and Node.js + Express (Backend).

---

## 📁 Project Structure

```
mini-local-business-dashboard/
├── frontend/      # React + Tailwind
└── backend/       # Node.js + Express
```

---

## 🧑‍💻 1. Setup Instructions

### 🔧 Prerequisites
- Node.js & npm installed
- GitHub account for deployment
- Vercel (for frontend) and Render (for backend)

---

## 🚀 2. Frontend Setup (React + Tailwind)

### 📦 Local Development
```bash
cd frontend
npm install
npm run dev
```

### 🌐 Deployment on Vercel
1. Go to [https://vercel.com](https://vercel.com)
2. Import GitHub repo or upload `frontend/` folder
3. Set `Framework = Vite` and root directory = `frontend`
4. Click **Deploy**

---

## 🛠️ 3. Backend Setup (Node.js + Express)

### 📦 Local Development
```bash
cd backend
npm install
node index.js
```
Runs on: `http://localhost:5000`

### 🌐 Deployment on Render
1. Go to [https://render.com](https://render.com)
2. Click **New Web Service**
3. Connect GitHub repo or upload `backend/`
4. Set:
   - **Build Command:** `npm install`
   - **Start Command:** `node index.js`
   - **Node Version:** `>=14`
   - **Root Directory:** `backend`
5. Click **Create Web Service**

---

## 🔁 API Endpoints

### `POST /business-data`
Returns mock business data and headline

```json
{
  "rating": 4.3,
  "reviews": 127,
  "headline": "Why Cake & Co is Mumbai's Sweetest Spot in 2025"
}
```

### `GET /regenerate-headline?name=...&location=...`
Returns random headline

---

## ✅ Features
- React + Tailwind UI
- Form validation + Global state
- Loading spinners & animation
- Deployed frontend/backend

---

## 📤 Submission
- Upload repo to GitHub
- Deploy frontend (Vercel) + backend (Render)
- Email your live links and GitHub repo

---
